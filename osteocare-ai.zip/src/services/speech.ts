// Speech Recognition & Synthesis Service for OsteoCare-AI

// Polyfill types for Web Speech API
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export function isSpeechRecognitionSupported(): boolean {
  return typeof window !== 'undefined' && Boolean(window.SpeechRecognition || window.webkitSpeechRecognition);
}

export function isSpeechSynthesisSupported(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

export function isMediaRecorderSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    typeof navigator !== 'undefined' &&
    Boolean(navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function' && window.MediaRecorder)
  );
}

export interface SpeechRecognitionHandlers {
  onStart?: () => void;
  onResult: (transcript: string, isFinal: boolean) => void;
  onError: (errorMessage: string, errorType?: string) => void;
  onEnd: () => void;
}

let activeRecognition: any = null;

export function startSpeechRecognition(
  lang: 'en-IN' | 'ta-IN' = 'en-IN',
  handlers: SpeechRecognitionHandlers
): () => void {
  if (!isSpeechRecognitionSupported()) {
    handlers.onError(
      'Speech recognition is not supported in this browser.',
      'not-supported'
    );
    handlers.onEnd();
    return () => {};
  }

  // Stop any ongoing instance
  if (activeRecognition) {
    try {
      activeRecognition.abort();
    } catch {
      // ignore
    }
    activeRecognition = null;
  }

  const SpeechRecognitionConstructor = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRecognitionConstructor();
  activeRecognition = recognition;

  recognition.lang = lang;
  recognition.interimResults = true;
  recognition.continuous = true; // allow continuous listening while user holds button
  recognition.maxAlternatives = 1;

  recognition.onstart = () => {
    handlers.onStart?.();
  };

  recognition.onresult = (event: any) => {
    let interimTranscript = '';
    let finalTranscript = '';

    for (let i = 0; i < event.results.length; ++i) {
      const part = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        finalTranscript += part;
      } else {
        interimTranscript += part;
      }
    }

    const transcript = finalTranscript || interimTranscript;
    handlers.onResult(transcript, Boolean(finalTranscript));
  };

  recognition.onerror = (event: any) => {
    let msg = 'Voice recognition error.';
    if (event.error === 'not-allowed') {
      msg = 'Microphone permission was denied. Please allow microphone access in your browser settings to speak.';
    } else if (event.error === 'no-speech') {
      msg = 'No voice input was detected. Please try speaking again closer to the microphone.';
    } else if (event.error === 'audio-capture') {
      msg = 'No microphone was found. Please ensure a microphone is connected.';
    } else if (event.error === 'network') {
      msg = 'Speech recognition network error. Please check your connection.';
    }
    handlers.onError(msg, event.error);
  };

  recognition.onend = () => {
    activeRecognition = null;
    handlers.onEnd();
  };

  try {
    recognition.start();
  } catch (err: any) {
    handlers.onError('Unable to initiate microphone listening. ' + (err?.message || ''));
    handlers.onEnd();
  }

  return () => {
    if (activeRecognition) {
      try {
        activeRecognition.stop();
      } catch {
        // ignore
      }
      activeRecognition = null;
    }
  };
}

// MediaRecorder Audio Capture Controller for browser fallback
export interface MediaRecorderController {
  stop: () => Promise<Blob | null>;
  cancel: () => void;
}

export async function startAudioRecording(
  onVolumeChange?: (volume: number) => void
): Promise<MediaRecorderController> {
  if (!isMediaRecorderSupported()) {
    throw new Error('Audio recording is not supported in this browser.');
  }

  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const mediaRecorder = new MediaRecorder(stream);
  const chunks: Blob[] = [];

  // Setup AudioContext for real-time waveform volume visualization
  let audioContext: AudioContext | null = null;
  let analyser: AnalyserNode | null = null;
  let animFrameId: number | null = null;

  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass && onVolumeChange) {
      audioContext = new AudioContextClass();
      analyser = audioContext.createAnalyser();
      analyser.fftSize = 64;
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const checkVolume = () => {
        if (!analyser) return;
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const average = sum / bufferLength;
        const normalized = Math.min(100, Math.round((average / 128) * 100));
        onVolumeChange(normalized);
        animFrameId = requestAnimationFrame(checkVolume);
      };
      checkVolume();
    }
  } catch {
    // Volume visualizer is optional
  }

  mediaRecorder.ondataavailable = (e) => {
    if (e.data.size > 0) {
      chunks.push(e.data);
    }
  };

  mediaRecorder.start(100);

  const cleanupAudio = () => {
    if (animFrameId) cancelAnimationFrame(animFrameId);
    if (audioContext && audioContext.state !== 'closed') {
      audioContext.close().catch(() => {});
    }
    stream.getTracks().forEach((track) => track.stop());
  };

  return {
    stop: (): Promise<Blob | null> => {
      return new Promise((resolve) => {
        mediaRecorder.onstop = () => {
          cleanupAudio();
          if (chunks.length === 0) {
            resolve(null);
          } else {
            const blob = new Blob(chunks, { type: mediaRecorder.mimeType || 'audio/webm' });
            resolve(blob);
          }
        };
        try {
          mediaRecorder.stop();
        } catch {
          cleanupAudio();
          resolve(null);
        }
      });
    },
    cancel: () => {
      cleanupAudio();
      try {
        if (mediaRecorder.state !== 'inactive') {
          mediaRecorder.stop();
        }
      } catch {
        // ignore
      }
    },
  };
}

let activeAudioElement: HTMLAudioElement | null = null;

// Clean text for natural speech synthesis
export function cleanTextForSpeech(text: string): string {
  return text
    .replace(/[*#_`>~]/g, '') // remove markdown symbols
    .replace(/https?:\/\/\S+/g, '') // remove URLs
    .replace(/\s+/g, ' ')
    .trim();
}

// Detect whether text is primarily Tamil
export function containsTamil(text: string): boolean {
  return /[\u0B80-\u0BFF]/.test(text);
}

// Speak text using browser SpeechSynthesis with audio element fallback
export function speakText(
  text: string,
  callbacks: {
    onStart?: () => void;
    onEnd?: () => void;
    onError?: (err: string) => void;
  }
): () => void {
  stopSpeaking();

  const cleaned = cleanTextForSpeech(text);
  if (!cleaned) {
    callbacks.onEnd?.();
    return () => {};
  }

  const isTamil = containsTamil(cleaned);

  if (!isSpeechSynthesisSupported()) {
    callbacks.onError?.('Text-to-speech is not supported in this browser.');
    callbacks.onEnd?.();
    return () => {};
  }

  const utterance = new SpeechSynthesisUtterance(cleaned);
  utterance.rate = isTamil ? 0.9 : 0.95;
  utterance.pitch = 1.0;
  utterance.lang = isTamil ? 'ta-IN' : 'en-IN';

  // Look for matching voices if available
  const voices = window.speechSynthesis.getVoices();
  if (isTamil) {
    const tamilVoice = voices.find(
      (v) => v.lang.startsWith('ta') || v.name.toLowerCase().includes('tamil')
    );
    if (tamilVoice) {
      utterance.voice = tamilVoice;
    }
  } else {
    const enVoice = voices.find(
      (v) => v.lang === 'en-IN' || (v.lang.startsWith('en') && !v.name.includes('Robot'))
    );
    if (enVoice) {
      utterance.voice = enVoice;
    }
  }

  utterance.onstart = () => {
    callbacks.onStart?.();
  };

  utterance.onend = () => {
    callbacks.onEnd?.();
  };

  utterance.onerror = (e) => {
    if (e.error === 'canceled' || e.error === 'interrupted') {
      callbacks.onEnd?.();
      return;
    }
    callbacks.onError?.('Audio playback was interrupted.');
    callbacks.onEnd?.();
  };

  window.speechSynthesis.speak(utterance);

  return () => {
    stopSpeaking();
  };
}

export function stopSpeaking(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // ignore
    }
  }
  if (activeAudioElement) {
    try {
      activeAudioElement.pause();
      activeAudioElement.src = '';
    } catch {
      // ignore
    }
    activeAudioElement = null;
  }
}
