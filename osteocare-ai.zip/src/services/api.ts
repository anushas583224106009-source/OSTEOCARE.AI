import { ChatMessage } from '../types';

export interface ChatResponse {
  success?: boolean;
  reply?: string;
  error?: string;
  timestamp?: string;
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export async function sendMessageToGemini(
  message: string,
  history: ChatMessage[]
): Promise<string> {
  const payload = {
    message: message.trim(),
    history: history.map((m) => ({
      role: m.role,
      content: m.content,
    })),
  };

  const maxAttempts = 3;
  let lastError: any = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 28000);

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      // If server returned 502/503/504, it might be restarting or warming up
      if (response.status === 502 || response.status === 503 || response.status === 504) {
        if (attempt < maxAttempts) {
          await sleep(1000 * attempt);
          continue;
        }
      }

      const contentType = response.headers.get('content-type') || '';

      if (!contentType.includes('application/json')) {
        const rawText = await response.text();
        if (
          rawText.toLowerCase().includes('<!doctype') ||
          rawText.toLowerCase().includes('<html')
        ) {
          if (attempt < maxAttempts) {
            await sleep(1200);
            continue;
          }
          throw new Error(
            'The medical consultation service is currently initializing. Please click "Retry" in a moment.'
          );
        }
        throw new Error(
          `Unexpected server response (HTTP ${response.status}). Please try again.`
        );
      }

      const data: ChatResponse = await response.json();

      if (data.success === false || data.error) {
        throw new Error(
          data.error || 'The AI service encountered an error while processing your request.'
        );
      }

      if (typeof data.reply === 'string' && data.reply.trim().length > 0) {
        return data.reply;
      }

      throw new Error('No response was generated. Please try asking your question again.');
    } catch (err: any) {
      lastError = err;
      // If it was an abort/timeout or network fetch error and we still have attempts, retry
      if (attempt < maxAttempts && (err?.name === 'AbortError' || err?.name === 'TypeError')) {
        await sleep(1000 * attempt);
        continue;
      }
      break;
    }
  }

  // If retries failed, provide user-friendly message
  const isTamil = /[\u0B80-\u0BFF]/.test(message);
  const errMsg = lastError?.message || '';

  if (
    errMsg.includes('API_KEY') ||
    errMsg.includes('Secrets panel') ||
    errMsg.includes('Gemini API key')
  ) {
    throw new Error(errMsg);
  }

  if (isTamil) {
    throw new Error(
      'இணையத் தொடர்பு அல்லது சேவையில் தற்காலிகத் தடை ஏற்பட்டுள்ளது. கீழே உள்ள "மீண்டும் முயற்சி" பட்டனை அழுத்தவும் அல்லது அவசர உதவிக்கு 108-ஐ அழைக்கவும்.'
    );
  }

  throw new Error(
    'Unable to connect to the healthcare consultation service. Please check your connection and click "Retry", or call 108 for medical emergencies.'
  );
}

export async function fetchServerTTS(text: string): Promise<string | null> {
  try {
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({ text }),
    });

    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return null;
    }

    const data = await res.json();
    return data.audioBase64 || null;
  } catch (err) {
    console.error('Server TTS error:', err);
    return null;
  }
}

export async function checkServerHealth(): Promise<{ hasApiKey: boolean; appName: string }> {
  try {
    const res = await fetch('/api/health', {
      headers: { 'Accept': 'application/json' },
    });
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return { hasApiKey: false, appName: 'OsteoCare-AI' };
    }
    const data = await res.json();
    return {
      hasApiKey: Boolean(data.hasApiKey),
      appName: data.appName || 'OsteoCare-AI',
    };
  } catch {
    return { hasApiKey: false, appName: 'OsteoCare-AI' };
  }
}

export async function transcribeAudioWithServer(
  audioBlob: Blob
): Promise<{ transcript: string; detectedLanguage: 'ta' | 'en' }> {
  // Convert Blob to base64
  const arrayBuffer = await audioBlob.arrayBuffer();
  const bytes = new Uint8Array(arrayBuffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  const audioBase64 = btoa(binary);

  const res = await fetch('/api/transcribe', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    body: JSON.stringify({
      audioBase64,
      mimeType: audioBlob.type || 'audio/webm',
    }),
  });

  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    throw new Error('Server returned unexpected response during audio transcription.');
  }

  const data = await res.json();
  if (data.success === false || data.error) {
    throw new Error(data.error || 'Transcription failed.');
  }

  return {
    transcript: data.transcript || '',
    detectedLanguage: data.detectedLanguage || (/[\\u0B80-\\u0BFF]/.test(data.transcript || '') ? 'ta' : 'en'),
  };
}
