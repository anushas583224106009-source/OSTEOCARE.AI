import React from 'react';
import { PhoneCall, Phone, ShieldCheck, HeartPulse, Building2, MapPin } from 'lucide-react';
import { HELPLINE_CONTACTS } from '../data/educationData';
import { Language } from '../types';

interface HelplineViewProps {
  lang: Language;
}

export const HelplineView: React.FC<HelplineViewProps> = ({ lang }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-700 mb-1">
          <PhoneCall className="w-4 h-4" />
          <span>{lang === 'en' ? 'Emergency & Hospital Support' : 'அவசர உதவி & மருத்துவமனைகள்'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
          {lang === 'en' ? 'Tamil Nadu Healthcare Helplines' : 'தமிழ்நாடு அவசர மற்றும் மருத்துவ உதவி எண்கள்'}
        </h1>
        <p className="text-slate-600 text-sm sm:text-base mt-1 max-w-3xl">
          {lang === 'en'
            ? 'Free 24x7 toll-free helpline numbers for medical emergencies, government hospital guidance, ambulance services, and orthopedic health insurance in Tamil Nadu.'
            : 'தமிழ்நாடு அரசு வழங்கும் 24 மணி நேர இலவச மருத்துவ ஆலோசனை, ஆம்புலன்ஸ் சேவை மற்றும் மருத்துவக் காப்பீட்டு உதவி எண்கள்.'}
        </p>
      </div>

      {/* Grid of Helpline Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {HELPLINE_CONTACTS.map((hl) => {
          return (
            <div
              key={hl.number}
              className={`rounded-xl border p-5 shadow-2xs flex flex-col justify-between gap-4 transition-all ${
                hl.isEmergency
                  ? 'bg-rose-50/50 border-rose-200 hover:border-rose-300'
                  : 'bg-white border-slate-200 hover:border-teal-300'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span
                    className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${
                      hl.isEmergency
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-teal-50 text-teal-800 border border-teal-200'
                    }`}
                  >
                    {hl.badge}
                  </span>
                  <span className="text-xs text-slate-500 font-medium">Toll-Free</span>
                </div>

                <h2 className="text-lg font-bold text-slate-900">
                  {lang === 'ta' ? hl.titleTa : hl.titleEn}
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {lang === 'ta' ? hl.descriptionTa : hl.descriptionEn}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200/60 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-500 block">Dial Number:</span>
                  <span className="text-xl sm:text-2xl font-bold font-mono text-slate-900 tracking-tight">
                    {hl.number}
                  </span>
                </div>

                <a
                  href={`tel:${hl.number}`}
                  className={`px-4 py-2 rounded-lg font-semibold text-xs flex items-center gap-1.5 transition-colors shadow-xs ${
                    hl.isEmergency
                      ? 'bg-rose-600 hover:bg-rose-700 text-white'
                      : 'bg-teal-600 hover:bg-teal-700 text-white'
                  }`}
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{lang === 'en' ? 'Call Now' : 'இப்போதே அழைக்க'}</span>
                </a>
              </div>
            </div>
          );
        })}
      </div>

      {/* Tamil Nadu Public Health Infrastructure Information */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6 shadow-2xs">
        <div className="flex items-center gap-2">
          <Building2 className="w-5 h-5 text-teal-700" />
          <h2 className="text-lg sm:text-xl font-bold text-slate-900">
            {lang === 'en'
              ? 'Where to Seek Orthopedic Care in Tamil Nadu'
              : 'தமிழ்நாட்டில் எங்கு எலும்பு சிகிச்சை பெறலாம்?'}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
              <MapPin className="w-4 h-4 text-teal-600" />
              <span>Primary Health Centres (PHC)</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              {lang === 'en'
                ? 'Best for immediate wound washing, sterile dressing, antiseptic care, and Tetanus (TT) injections in rural villages and taluks.'
                : 'கிராமப்புறங்களில் ஆரம்பகட்ட காயம் கழுவுதல், கட்டு போடுதல் மற்றும் TT தடுப்பூசி போடுவதற்கு ஏற்றது.'}
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
              <HeartPulse className="w-4 h-4 text-teal-600" />
              <span>District Headquarters Hospitals (GH)</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              {lang === 'en'
                ? 'Equipped with dedicated Orthopedic Surgeons, X-ray machines, blood culture labs, and inpatient beds for multi-week IV antibiotic regimens.'
                : 'எலும்பு முறிவு மருத்துவர்கள், எக்ஸ்-ரே வசதி, இரத்தப் பரிசோதனை ஆய்வகம் மற்றும் பல வாரங்கள் தங்கி ஊசி மருந்து செலுத்தும் வசதி உள்ளது.'}
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
              <ShieldCheck className="w-4 h-4 text-teal-600" />
              <span>Government Medical Colleges</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              {lang === 'en'
                ? 'Equipped with advanced MRI, CT scans, and specialized orthopedic operating theatres for chronic osteomyelitis debridement and bone reconstruction.'
                : 'எம்.ஆர்.ஐ ஸ்கேன் வசதி மற்றும் நாள்பட்ட எலும்பு அழுகல் அறுவை சிகிச்சைக்கான அதிநவீன மருத்துவக் கல்லூரி மருத்துவமனைகள்.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
