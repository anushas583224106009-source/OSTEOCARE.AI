import React from 'react';
import {
  ShieldAlert,
  Droplets,
  Bandage,
  Syringe,
  Footprints,
  XCircle,
  CheckCircle2,
  PhoneCall,
  Sparkles,
} from 'lucide-react';
import { Language } from '../types';

interface WorkerViewProps {
  lang: Language;
  onAskQuestion: (query: string) => void;
}

export const WorkerView: React.FC<WorkerViewProps> = ({ lang, onAskQuestion }) => {
  const steps = [
    {
      num: '01',
      titleEn: 'Immediate Running Water & Soap Wash',
      titleTa: 'ஓடும் தண்ணீரில் சோப்பு போட்டு உடனே கழுவுதல்',
      descEn: 'Hold the punctured limb under clean running tap or pump water. Wash thoroughly with bathing soap for at least 3-5 minutes to flush out soil, microbes, and thorn fragments.',
      descTa: 'காயம்பட்ட கையை அல்லது காலை சுத்தமான ஓடும் தண்ணீரில் காட்டி, குளியல் சோப்பு போட்டு குறைந்தது 3 முதல் 5 நிமிடங்கள் வரை மண்ணும் தூசியும் போக நன்கு கழுவ வேண்டும்.',
      icon: Droplets,
    },
    {
      num: '02',
      titleEn: 'Disinfect & Apply Sterile Dressing',
      titleTa: 'கிருமிநாசினி பூசி தூய துணியால் கட்டுதல்',
      descEn: 'Apply povidone iodine or antiseptic liquid/ointment. Cover loosely with sterile gauze or clean washed cloth. Never leave open to field flies or dirt.',
      descTa: 'போவிடோன் அயோடின் (Povidone Iodine) போன்ற கிருமிநாசினி திரவம் அல்லது களிம்பு பூசி, சுத்தமான துணியால் கட்ட வேண்டும். ஈக்கள் அல்லது தூசி படிய விடக் கூடாது.',
      icon: Bandage,
    },
    {
      num: '03',
      titleEn: 'Tetanus Toxoid (TT) Injection',
      titleTa: 'டெட்டனஸ் (TT) தடுப்பூசி போடுதல்',
      descEn: 'Visit your nearest Primary Health Centre (PHC) within 24 to 48 hours for a Tetanus Toxoid shot, especially if the injury was caused by rusty metal, thorns, or soil.',
      descTa: 'துருப்பிடித்த ஆணி, முள் அல்லது மண் பட்ட காயங்களுக்கு 24 முதல் 48 மணி நேரத்திற்குள் ஆரம்ப சுகாதார நிலையத்திற்குச் சென்று TT ஊசி போட்டுக் கொள்ள வேண்டும்.',
      icon: Syringe,
    },
    {
      num: '04',
      titleEn: 'Daily Inspection for Bone Red Flags',
      titleTa: 'எலும்பு தொற்று அறிகுறிகளை தினமும் கவனித்தல்',
      descEn: 'Watch for deep throbbing bone ache, increasing heat/swelling around the bone, pus discharge, or sudden fever. These indicate bacteria have breached the bone.',
      descTa: 'காயத்தைச் சுற்றி வீக்கம், அதிகமான சூடு, நடுக்கத்துடன் காய்ச்சல் அல்லது எலும்பின் உள்ளிருந்து தீவிர குடைச்சல் வலி வருகிறதா என உன்னிப்பாகக் கவனிக்க வேண்டும்.',
      icon: ShieldAlert,
    },
    {
      num: '05',
      titleEn: 'Protective Footwear & Daily Care',
      titleTa: 'பாதுகாப்பு காலணிகள் மற்றும் பாதப் பராமரிப்பு',
      descEn: 'Wear rubber gumboots or slippers in agricultural fields, brick kilns, and quarries. If you have diabetes, check the soles of your feet every evening with a mirror.',
      descTa: 'வயல்வெளிகள், செங்கல் சூளை மற்றும் கட்டுமான இடங்களில் ரப்பர் பூட்ஸ் அல்லது செருப்பு அணியவும். சர்க்கரை நோய் உள்ளவர்கள் தினமும் மாலையில் பாதங்களை பரிசோதிக்க வேண்டும்.',
      icon: Footprints,
    },
  ];

  const myths = [
    {
      mythEn: 'Applying cow dung or soil cures thorn pricks.',
      mythTa: 'சாணம் அல்லது புத்து மண் வைத்தால் முள் காயம் ஆறிவிடும்.',
      factEn: 'Cow dung is loaded with virulent anaerobic bacteria (Clostridium, Tetanus, Staph) that rapidly invade bone marrow and cause severe osteomyelitis.',
      factTa: 'சாணத்தில் கொடிய பாக்டீரியாக்கள் நிறைந்துள்ளன. அவை நேரடியாக எலும்பு மச்சைக்குள் சென்று எலும்பை அழுகச் செய்யும்.',
    },
    {
      mythEn: 'Covering open cuts with ground battery powder or kerosene prevents infection.',
      mythTa: 'காயத்தில் பேட்டரி தூள் அல்லது மண்ணெண்ணெய் ஊற்றினால் கிருமி அழியும்.',
      factEn: 'Chemicals burn healthy tissue and kill local blood circulation, leaving bone unprotected against aggressive bacterial colonization.',
      factTa: 'இவை உடலின் இரத்த ஓட்டத்தை அழித்து திசுக்களைப் புண்ணாக்கும். இதனால் எலும்புத் தொற்று மிக வேகமாகப் பரவும்.',
    },
    {
      mythEn: 'Buying painkiller tablets from a local shop cures the deep bone ache.',
      mythTa: 'மருந்துக் கடையில் வலி மாத்திரை வாங்கி சாப்பிட்டால் போதும்.',
      factEn: 'Painkillers only numb nerve pain temporarily while the bacteria destroy bone architecture. Only prescribed antibiotics cure bone infection.',
      factTa: 'வலி மாத்திரைகள் வலியை மட்டுமே தற்காலிகமாக மறைக்கும். ஆனால் பாக்டீரியா எலும்பை அரித்துக்கொண்டே இருக்கும். மருத்துவர் தரும் ஆன்டிபயாடிக் மட்டுமே மருந்தாகும்.',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-700 mb-1">
          <Footprints className="w-4 h-4" />
          <span>{lang === 'en' ? 'Occupational Health Guide' : 'தொழிலாளர் பாதுகாப்பு வழிகாட்டி'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
          {lang === 'en'
            ? 'First Aid & Bone Protection for Field Workers'
            : 'விவசாய மற்றும் கூலித் தொழிலாளர்களுக்கான முதலுதவி'}
        </h1>
        <p className="text-slate-600 text-sm sm:text-base mt-1 max-w-3xl">
          {lang === 'en'
            ? 'Puncture wounds from Karuvelam thorns (கருவேல முள்), rusty nails, and agricultural implements are the leading cause of osteomyelitis in rural Tamil Nadu. Follow this gold-standard protocol.'
            : 'கருவேல முள், துருப்பிடித்த ஆணி, உழவு கருவிகள் போன்றவற்றால் ஏற்படும் காயங்களே தமிழ்நாட்டில் எலும்பு தொற்றுக்கு முக்கியக் காரணமாகும்.'}
        </p>
      </div>

      {/* Hero illustration banner */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xs grid grid-cols-1 md:grid-cols-12 items-center">
        <div className="md:col-span-5 p-6 sm:p-8 space-y-4">
          <div className="inline-block px-3 py-1 bg-teal-50 border border-teal-200 text-teal-800 rounded-md text-xs font-semibold">
            {lang === 'en' ? 'Field Protocol' : 'வயல்வெளி முதலுதவி நெறிமுறை'}
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
            {lang === 'en'
              ? 'Never Ignore a Field Cut or Puncture'
              : 'சிறிய முள் குத்தலாக இருந்தாலும் அலட்சியம் செய்யாதீர்கள்'}
          </h2>
          <p className="text-slate-600 text-sm leading-relaxed">
            {lang === 'en'
              ? 'Bacteria thrive in soil and water. When pushed deep into tissue by a thorn or nail, they colonize the bone cortex within 48 to 72 hours if untreated.'
              : 'மண் மற்றும் சேற்றில் உள்ள பாக்டீரியாக்கள் முள் வழியாக ஆழமாகச் சென்று 48 முதல் 72 மணி நேரத்திற்குள் எலும்பைத் தாக்கும் அபாயம் உள்ளது.'}
          </p>
          <button
            onClick={() =>
              onAskQuestion(
                lang === 'ta'
                  ? 'வயலில் வேலை செய்யும் போது முள் குத்தினால் செய்ய வேண்டிய உடனடி முதலுதவி என்ன?'
                  : 'What immediate first aid should a farm worker do after a thorn or nail puncture?'
              )
            }
            className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'Ask AI for First Aid Advice' : 'AI-யிடம் முதலுதவி வழிகாட்டல் கேட்க'}</span>
          </button>
        </div>
        <div className="md:col-span-7 h-64 md:h-80 bg-slate-100 overflow-hidden">
          <img
            src="/src/assets/images/rural_worker_care_1791864742273.jpg"
            alt="Doctor explaining wound care to rural workers"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      {/* 5-Step Protocol Cards */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-slate-900">
          {lang === 'en' ? '5-Step Puncture Care Protocol' : '5 படிநிலைகள் கொண்ட முதலுதவி விதிமுறை'}
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {steps.map((st) => {
            const Icon = st.icon;
            return (
              <div
                key={st.num}
                className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-3 relative hover:border-teal-400 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-lg bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-700">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-mono font-bold text-teal-700 bg-teal-50/80 px-2 py-0.5 rounded">
                    STEP {st.num}
                  </span>
                </div>
                <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                  {lang === 'ta' ? st.titleTa : st.titleEn}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {lang === 'ta' ? st.descTa : st.descEn}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Myths vs Facts Section */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-5">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-rose-600" />
          <h2 className="text-lg sm:text-xl font-bold text-slate-900">
            {lang === 'en' ? 'Dangerous Traditional Habits vs Medical Science' : 'தவறான நாட்டுப் பழக்கங்களும் - உண்மைகளும்'}
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-slate-600 max-w-3xl">
          {lang === 'en'
            ? 'Many rural patients develop chronic osteomyelitis not from the initial thorn itself, but from applying non-sterile materials directly into the open cut.'
            : 'பல தொழிலாளர்களுக்கு எலும்பு அழுகல் நோய் முள்ளால் வருவதை விட, காயத்தின் மேல் அசுத்தமான பொருட்களை பூசுவதாலேயே ஏற்படுகிறது.'}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {myths.map((m, idx) => (
            <div key={idx} className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs space-y-3">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-bold text-rose-700">
                  <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{lang === 'en' ? 'Dangerous Myth' : 'தவறான பழக்கம்'}</span>
                </div>
                <p className="text-xs font-semibold text-slate-800">
                  {lang === 'ta' ? m.mythTa : m.mythEn}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-bold text-teal-700">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                  <span>{lang === 'en' ? 'Medical Truth' : 'மருத்துவ உண்மை'}</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {lang === 'ta' ? m.factTa : m.factEn}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Primary Health Centre notice */}
      <div className="p-4 bg-teal-50 border border-teal-200 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-bold text-teal-950">
            {lang === 'en' ? 'Government Primary Health Centre (PHC) Free Care' : 'அரசு ஆரம்ப சுகாதார நிலையங்களில் இலவச சிகிச்சை'}
          </h3>
          <p className="text-xs text-teal-800 mt-0.5">
            {lang === 'en'
              ? 'Wound cleaning, sterile dressings, and Tetanus injections are completely free at all Tamil Nadu Government PHCs.'
              : 'தமிழ்நாடு அரசு ஆரம்ப சுகாதார நிலையங்களில் காயக் கட்டு போடுதல், TT ஊசி மற்றும் மருந்துகள் முற்றிலும் இலவசம்.'}
          </p>
        </div>
        <button
          onClick={() =>
            onAskQuestion(
              lang === 'ta'
                ? 'ஆரம்ப சுகாதார நிலையத்தில் எலும்பு தொற்றுக்கு என்ன பரிசோதனைகள் செய்வார்கள்?'
                : 'What tests and treatments are done for bone infection at a Government Hospital?'
            )
          }
          className="px-3.5 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-lg text-xs font-semibold shrink-0 cursor-pointer shadow-xs"
        >
          {lang === 'en' ? 'Ask AI about PHC Services' : 'அரசு மருத்துவமனை பற்றி கேட்க'}
        </button>
      </div>
    </div>
  );
};
