import React from 'react';
import { AlertCircle } from 'lucide-react';
import { Language } from '../types';

interface DisclaimerBannerProps {
  lang: Language;
}

export const DisclaimerBanner: React.FC<DisclaimerBannerProps> = ({ lang }) => {
  return (
    <div className="bg-amber-50/80 border-b border-amber-200/80 px-4 py-2 text-xs text-amber-900">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" aria-hidden="true" />
          <p className="line-clamp-1 sm:line-clamp-none">
            {lang === 'en' ? (
              <span>
                <strong>Educational Notice:</strong> OsteoCare-AI provides healthcare education only and does not diagnose illnesses or prescribe medication. In case of severe trauma, deep pus, or high fever, visit your nearest Government Hospital (GH) or call 108.
              </span>
            ) : (
              <span>
                <strong>மருத்துவ விழிப்புணர்வு அறிவிப்பு:</strong> OsteoCare-AI கல்வி விழிப்புணர்வுக்காக மட்டுமே. இது மருத்துவ நோயறிதல் அல்லது மருந்துச் சீட்டு அல்ல. கடுமையான வலி, சீழ் அல்லது காய்ச்சல் இருந்தால் உடனடியாக அரசு மருத்துவமனைக்குச் செல்லவும் அல்லது 108 ஐ அழைக்கவும்.
              </span>
            )}
          </p>
        </div>
      </div>
    </div>
  );
};
