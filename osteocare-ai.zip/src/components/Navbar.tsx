import React from 'react';
import { Globe, PhoneCall } from 'lucide-react';
import { Language } from '../types';
import { OsteoCareLogo } from './OsteoCareLogo';

interface NavbarProps {
  activeTab: 'chat' | 'guide' | 'safety' | 'helplines';
  setActiveTab: (tab: 'chat' | 'guide' | 'safety' | 'helplines') => void;
  lang: Language;
  setLang: (lang: Language) => void;
  onEmergencyClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  lang,
  setLang,
  onEmergencyClick,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Official Brand Logo Lockup */}
        <button
          onClick={() => setActiveTab('chat')}
          className="text-left cursor-pointer group shrink-0 focus:outline-hidden"
          title="OsteoCare-AI"
        >
          <OsteoCareLogo variant="horizontal" size="sm" showTagline={false} />
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
          <button
            onClick={() => setActiveTab('chat')}
            className={`whitespace-nowrap cursor-pointer transition-colors pb-0.5 ${
              activeTab === 'chat'
                ? 'text-teal-700 font-semibold border-b-2 border-teal-600'
                : 'hover:text-slate-900'
            }`}
          >
            {lang === 'en' ? 'AI Consultation' : 'AI மருத்துவ ஆலோசனை'}
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`whitespace-nowrap cursor-pointer transition-colors pb-0.5 ${
              activeTab === 'guide'
                ? 'text-teal-700 font-semibold border-b-2 border-teal-600'
                : 'hover:text-slate-900'
            }`}
          >
            {lang === 'en' ? 'Bone Infection Guide' : 'எலும்பு தொற்று வழிகாட்டி'}
          </button>

          <button
            onClick={() => setActiveTab('safety')}
            className={`whitespace-nowrap cursor-pointer transition-colors pb-0.5 ${
              activeTab === 'safety'
                ? 'text-teal-700 font-semibold border-b-2 border-teal-600'
                : 'hover:text-slate-900'
            }`}
          >
            {lang === 'en' ? 'Worker First Aid' : 'தொழிலாளர் முதலுதவி'}
          </button>

          <button
            onClick={() => setActiveTab('helplines')}
            className={`whitespace-nowrap cursor-pointer transition-colors pb-0.5 ${
              activeTab === 'helplines'
                ? 'text-teal-700 font-semibold border-b-2 border-teal-600'
                : 'hover:text-slate-900'
            }`}
          >
            {lang === 'en' ? 'Tamil Nadu Helplines' : 'தமிழ்நாடு உதவி எண்கள்'}
          </button>
        </nav>

        {/* Zone 3: Actions (Language toggle + Emergency 108) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setLang(lang === 'en' ? 'ta' : 'en')}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 hover:border-slate-300 transition-colors whitespace-nowrap cursor-pointer"
            title={lang === 'en' ? 'Switch to Tamil language' : 'ஆங்கிலத்திற்கு மாற்றவும்'}
          >
            <Globe className="w-3.5 h-3.5 text-teal-600" />
            <span>{lang === 'en' ? 'தமிழ்' : 'English'}</span>
          </button>

          <button
            onClick={onEmergencyClick}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-md bg-rose-600 text-white hover:bg-rose-700 transition-colors whitespace-nowrap shadow-xs cursor-pointer"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'Call 108' : '108 அவசரம்'}</span>
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-200 bg-slate-50 px-2 py-2 text-xs font-medium text-slate-600">
        <button
          onClick={() => setActiveTab('chat')}
          className={`px-2.5 py-1 rounded-sm whitespace-nowrap ${
            activeTab === 'chat' ? 'bg-white text-teal-700 font-semibold shadow-xs' : ''
          }`}
        >
          {lang === 'en' ? 'Chat' : 'உரையாடல்'}
        </button>
        <button
          onClick={() => setActiveTab('guide')}
          className={`px-2.5 py-1 rounded-sm whitespace-nowrap ${
            activeTab === 'guide' ? 'bg-white text-teal-700 font-semibold shadow-xs' : ''
          }`}
        >
          {lang === 'en' ? 'Guide' : 'வழிகாட்டி'}
        </button>
        <button
          onClick={() => setActiveTab('safety')}
          className={`px-2.5 py-1 rounded-sm whitespace-nowrap ${
            activeTab === 'safety' ? 'bg-white text-teal-700 font-semibold shadow-xs' : ''
          }`}
        >
          {lang === 'en' ? 'First Aid' : 'முதலுதவி'}
        </button>
        <button
          onClick={() => setActiveTab('helplines')}
          className={`px-2.5 py-1 rounded-sm whitespace-nowrap ${
            activeTab === 'helplines' ? 'bg-white text-teal-700 font-semibold shadow-xs' : ''
          }`}
        >
          {lang === 'en' ? 'Helpline' : 'உதவி'}
        </button>
      </div>
    </header>
  );
};
