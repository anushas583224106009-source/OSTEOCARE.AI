import React, { useState } from 'react';
import {
  BookOpen,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Shield,
  MessageSquare,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { EDUCATIONAL_SECTIONS } from '../data/educationData';
import { Language } from '../types';

interface EducationViewProps {
  lang: Language;
  onAskQuestion: (query: string) => void;
}

export const EducationView: React.FC<EducationViewProps> = ({ lang, onAskQuestion }) => {
  const [activeSectionId, setActiveSectionId] = useState<string>(EDUCATIONAL_SECTIONS[0].id);

  const activeSection =
    EDUCATIONAL_SECTIONS.find((s) => s.id === activeSectionId) || EDUCATIONAL_SECTIONS[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* View Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-700 mb-1">
          <BookOpen className="w-4 h-4" />
          <span>{lang === 'en' ? 'Public Health Knowledge Base' : 'பொது சுகாதார வழிகாட்டி'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
          {lang === 'en' ? 'Osteomyelitis (Bone Infection) Guide' : 'எலும்பு தொற்று விரிவான வழிகாட்டி'}
        </h1>
        <p className="text-slate-600 text-sm sm:text-base mt-1 max-w-3xl">
          {lang === 'en'
            ? 'A dedicated educational resource designed for manual laborers, farmers, and families in Tamil Nadu to prevent bone infections and avoid permanent disability.'
            : 'தமிழ்நாடு விவசாய மற்றும் கூலித் தொழிலாளர்கள், பொதுமக்கள் எலும்பு தொற்று வராமல் தற்காத்துக் கொள்ளவும் உரிய மருத்துவ சிகிச்சை பெறவும் வழிகாட்டி.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Navigation: Topics list */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-2 shadow-2xs space-y-1">
          <p className="px-3 py-2 text-xs font-bold text-slate-500 uppercase tracking-wider">
            {lang === 'en' ? 'Select Topic' : 'தலைப்பைத் தேர்ந்தெடுக்கவும்'}
          </p>
          {EDUCATIONAL_SECTIONS.map((sec, idx) => {
            const isSelected = sec.id === activeSectionId;
            return (
              <button
                key={sec.id}
                onClick={() => setActiveSectionId(sec.id)}
                className={`w-full text-left p-3 rounded-lg transition-all flex items-center justify-between gap-2 cursor-pointer ${
                  isSelected
                    ? 'bg-teal-50 border border-teal-200 text-teal-900 shadow-2xs'
                    : 'hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div>
                  <span className="text-[11px] font-mono text-teal-700 font-semibold block">
                    0{idx + 1}.
                  </span>
                  <span className="text-sm font-semibold line-clamp-1">
                    {lang === 'ta' ? sec.titleTa : sec.titleEn}
                  </span>
                </div>
                <ChevronRight
                  className={`w-4 h-4 shrink-0 transition-transform ${
                    isSelected ? 'text-teal-700 translate-x-0.5' : 'text-slate-400'
                  }`}
                />
              </button>
            );
          })}

          {/* Quick prompt trigger */}
          <div className="p-3 mt-4 bg-teal-50/60 border border-teal-100 rounded-lg">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-teal-900 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-teal-600" />
              <span>{lang === 'en' ? 'Have questions?' : 'சந்தேகம் உள்ளதா?'}</span>
            </div>
            <p className="text-xs text-slate-600 mb-2">
              {lang === 'en'
                ? 'Ask OsteoCare-AI for personalized, easy explanations in Tamil or English.'
                : 'எங்களின் AI உதவியாளரிடம் உங்கள் சொந்த மொழியில் சந்தேகங்களைக் கேளுங்கள்.'}
            </p>
            <button
              onClick={() =>
                onAskQuestion(
                  lang === 'ta'
                    ? `${activeSection.titleTa} பற்றி மேலும் எளிய விளக்கம் கூறவும்.`
                    : `Please explain more about ${activeSection.titleEn} in simple terms.`
                )
              }
              className="w-full py-1.5 px-3 bg-teal-600 hover:bg-teal-700 text-white rounded text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>{lang === 'en' ? 'Ask AI about this topic' : 'இந்த தலைப்பை பற்றி AI-யிடம் கேட்க'}</span>
            </button>
          </div>
        </div>

        {/* Right Content Pane */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs space-y-6">
          {/* Header */}
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              {lang === 'ta' ? activeSection.titleTa : activeSection.titleEn}
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              {lang === 'ta' ? activeSection.subtitleTa : activeSection.subtitleEn}
            </p>
          </div>

          {/* Featured Image if present */}
          {activeSection.image && (
            <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-50 relative group">
              <img
                src={activeSection.image}
                alt={lang === 'ta' ? activeSection.titleTa : activeSection.titleEn}
                className="w-full h-64 sm:h-80 object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="p-2.5 bg-slate-900/80 backdrop-blur-xs text-white text-xs flex items-center justify-between">
                <span>{lang === 'en' ? 'Clinical Awareness Graphic' : 'மருத்துவ விழிப்புணர்வு விளக்கப் படம்'}</span>
                <span className="text-[11px] text-teal-300 font-mono">OsteoCare-AI</span>
              </div>
            </div>
          )}

          {/* High-Risk Warning if any */}
          {(activeSection.warningEn || activeSection.warningTa) && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3 text-rose-950 text-xs sm:text-sm">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-rose-800">
                  {lang === 'en' ? 'Critical Safety Warning' : 'மிக முக்கியமான எச்சரிக்கை'}
                </p>
                <p className="mt-0.5">
                  {lang === 'ta' ? activeSection.warningTa : activeSection.warningEn}
                </p>
              </div>
            </div>
          )}

          {/* Educational Bullet Points */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">
              {lang === 'en' ? 'Key Educational Insights' : 'முக்கிய குறிப்புகள்'}
            </h3>
            <div className="grid grid-cols-1 gap-3">
              {(lang === 'ta' ? activeSection.contentTa : activeSection.contentEn).map(
                (item, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-lg bg-slate-50 border border-slate-100 flex items-start gap-3 text-sm text-slate-800"
                  >
                    <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                    <p className="leading-relaxed">{item}</p>
                  </div>
                )
              )}
            </div>
          </div>

          {/* Action CTA */}
          <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Shield className="w-4 h-4 text-teal-600" />
              <span>{lang === 'en' ? 'Medically reviewed educational data' : 'சரிபார்க்கப்பட்ட மருத்துவ விழிப்புணர்வுத் தகவல்'}</span>
            </div>
            <button
              onClick={() =>
                onAskQuestion(
                  lang === 'ta'
                    ? `எலும்பு தொற்று அறிகுறிகள் தென்பட்டால் உடனடியாக என்ன செய்ய வேண்டும்?`
                    : `What should I immediately do if I notice bone infection symptoms?`
                )
              }
              className="text-xs font-semibold text-teal-700 hover:text-teal-900 flex items-center gap-1 cursor-pointer"
            >
              <span>{lang === 'en' ? 'Consult AI Assistant now' : 'உடனடியாக AI-யிடம் ஆலோசனை பெறுக'}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
