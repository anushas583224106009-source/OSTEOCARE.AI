import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Send,
  Mic,
  Volume2,
  Square,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Info,
  AlertTriangle,
  Stethoscope,
  User,
  ShieldCheck,
  Trash2,
  CheckCircle2,
  Radio,
  Loader2,
  Languages,
} from 'lucide-react';
import { ChatMessage, Language } from '../types';
import { QUICK_QUESTIONS } from '../data/educationData';
import {
  startSpeechRecognition,
  isSpeechRecognitionSupported,
  startAudioRecording,
  MediaRecorderController,
  speakText,
  stopSpeaking,
  containsTamil,
} from '../services/speech';
import { transcribeAudioWithServer } from '../services/api';
import { OsteoCareLogo } from './OsteoCareLogo';

interface ChatViewProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  lang: Language;
  onSetLang?: (newLang: Language) => void;
  onClearChat: () => void;
  apiError: string | null;
  onDismissError: () => void;
  onRetry?: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  messages,
  onSendMessage,
  isLoading,
  lang,
  onSetLang,
  onClearChat,
  apiError,
  onDismissError,
  onRetry,
}) => {
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [isTranscribingFallback, setIsTranscribingFallback] = useState(false);
  const [micLanguage, setMicLanguage] = useState<'ta-IN' | 'en-IN'>(lang === 'ta' ? 'ta-IN' : 'en-IN');
  const [micNotice, setMicNotice] = useState<string | null>(null);
  const [detectedVoiceLang, setDetectedVoiceLang] = useState<'ta' | 'en' | null>(null);
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [audioVolume, setAudioVolume] = useState(0);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const stopListeningRef = useRef<(() => void) | null>(null);
  const mediaRecorderRef = useRef<MediaRecorderController | null>(null);
  const timerIntervalRef = useRef<any>(null);
  const isPressHoldingRef = useRef(false);
  const pressStartTimeRef = useRef(0);

  // Sync mic language with global language when it changes
  useEffect(() => {
    setMicLanguage(lang === 'ta' ? 'ta-IN' : 'en-IN');
  }, [lang]);

  // Scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading, liveTranscript]);

  const handleSend = () => {
    if (!inputText.trim() || isLoading) return;
    const textToSend = inputText.trim();
    setInputText('');
    setLiveTranscript('');
    setDetectedVoiceLang(null);
    onSendMessage(textToSend);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Timer for recording duration
  useEffect(() => {
    if (isRecording) {
      setRecordingDuration(0);
      timerIntervalRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    };
  }, [isRecording]);

  // Clean and insert transcribed text into input box
  const commitTranscribedText = useCallback(
    (transcript: string) => {
      const clean = transcript.trim();
      if (!clean) return;

      // Auto-detect language
      const isTamilSpeech = containsTamil(clean);
      const detected: 'ta' | 'en' = isTamilSpeech ? 'ta' : 'en';
      setDetectedVoiceLang(detected);
      if (onSetLang) {
        onSetLang(detected);
      }

      setInputText((prev) => {
        if (!prev.trim()) return clean;
        return `${prev.trim()} ${clean}`;
      });

      // Focus textarea so user can review or edit
      setTimeout(() => {
        textareaRef.current?.focus();
      }, 100);
    },
    [onSetLang]
  );

  // Start voice recording (ChatGPT style)
  const startRecordingVoice = async () => {
    setMicNotice(null);
    setLiveTranscript('');
    handleStopSpeaking();

    // Check if Web Speech API is supported
    if (isSpeechRecognitionSupported()) {
      try {
        setIsRecording(true);

        stopListeningRef.current = startSpeechRecognition(micLanguage, {
          onStart: () => {
            setIsRecording(true);
          },
          onResult: (transcript, isFinal) => {
            setLiveTranscript(transcript);
            if (isFinal && transcript.trim()) {
              commitTranscribedText(transcript);
            }
          },
          onError: (errMsg) => {
            setMicNotice(errMsg);
            setIsRecording(false);
            setLiveTranscript('');
          },
          onEnd: () => {
            // Only stop if not held
            if (!isPressHoldingRef.current) {
              setIsRecording(false);
            }
          },
        });
      } catch (err: any) {
        setMicNotice('Could not start speech recognition: ' + (err?.message || ''));
        setIsRecording(false);
      }
    } else {
      // Fallback: Use MediaRecorder + Server-side Gemini Transcribe
      try {
        setIsRecording(true);
        const controller = await startAudioRecording((vol) => {
          setAudioVolume(vol);
        });
        mediaRecorderRef.current = controller;
      } catch (err: any) {
        setIsRecording(false);
        setMicNotice(
          'Microphone permission denied or unsupported. Please allow microphone access in your browser settings.'
        );
      }
    }
  };

  // Stop voice recording and process speech
  const stopRecordingVoice = async (discard: boolean = false) => {
    setIsRecording(false);
    isPressHoldingRef.current = false;

    // If Web Speech API was active
    if (stopListeningRef.current) {
      stopListeningRef.current();
      stopListeningRef.current = null;
    }

    // If MediaRecorder fallback was active
    if (mediaRecorderRef.current) {
      const controller = mediaRecorderRef.current;
      mediaRecorderRef.current = null;

      if (discard) {
        controller.cancel();
        setLiveTranscript('');
        return;
      }

      try {
        setIsTranscribingFallback(true);
        const audioBlob = await controller.stop();
        if (audioBlob && audioBlob.size > 0) {
          const result = await transcribeAudioWithServer(audioBlob);
          if (result.transcript) {
            commitTranscribedText(result.transcript);
          }
        }
      } catch (err: any) {
        setMicNotice('Failed to transcribe audio. Please try speaking again.');
      } finally {
        setIsTranscribingFallback(false);
      }
    } else {
      if (!discard && liveTranscript.trim()) {
        commitTranscribedText(liveTranscript);
      }
    }

    setLiveTranscript('');
  };

  // Cancel recording and discard audio
  const handleCancelRecording = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    stopRecordingVoice(true);
  };

  // Finish recording and commit
  const handleFinishRecording = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    stopRecordingVoice(false);
  };

  // Press & Hold Event Handlers (ChatGPT style)
  const handleMicMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    isPressHoldingRef.current = true;
    pressStartTimeRef.current = Date.now();
    startRecordingVoice();
  };

  const handleMicMouseUp = (e: React.MouseEvent) => {
    e.preventDefault();
    const duration = Date.now() - pressStartTimeRef.current;
    // If held for more than 400ms, release immediately stops recording
    if (duration > 400) {
      stopRecordingVoice(false);
    } else {
      // If brief tap, keep recording locked until user taps done or cancel
      isPressHoldingRef.current = false;
    }
  };

  const handleMicTouchStart = (e: React.TouchEvent) => {
    isPressHoldingRef.current = true;
    pressStartTimeRef.current = Date.now();
    startRecordingVoice();
  };

  const handleMicTouchEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    const duration = Date.now() - pressStartTimeRef.current;
    if (duration > 400) {
      stopRecordingVoice(false);
    } else {
      isPressHoldingRef.current = false;
    }
  };

  // Text-To-Speech for assistant responses
  const handleSpeak = (messageId: string, text: string) => {
    if (currentlySpeakingId === messageId) {
      handleStopSpeaking();
      return;
    }

    handleStopSpeaking();
    setCurrentlySpeakingId(messageId);

    speakText(text, {
      onEnd: () => {
        setCurrentlySpeakingId(null);
      },
      onError: () => {
        setCurrentlySpeakingId(null);
      },
    });
  };

  const handleStopSpeaking = () => {
    stopSpeaking();
    setCurrentlySpeakingId(null);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Format message text with line breaks and bullet points cleanly
  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    return (
      <div className="space-y-2 text-sm sm:text-base leading-relaxed break-words">
        {lines.map((line, idx) => {
          const trimmed = line.trim();
          if (!trimmed) {
            return <div key={idx} className="h-2" />;
          }

          if (trimmed.startsWith('* ') || trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
            const bulletText = trimmed.replace(/^(\*|-|•)\s+/, '');
            return (
              <div key={idx} className="flex items-start gap-2 pl-1">
                <span className="text-teal-600 font-bold shrink-0 mt-1">•</span>
                <span className="flex-1">{parseInlineFormatting(bulletText)}</span>
              </div>
            );
          }

          const numMatch = trimmed.match(/^(\d+)\.\s+(.*)$/);
          if (numMatch) {
            return (
              <div key={idx} className="flex items-start gap-2 pl-1">
                <span className="text-teal-700 font-semibold shrink-0 tabular-nums">
                  {numMatch[1]}.
                </span>
                <span className="flex-1">{parseInlineFormatting(numMatch[2])}</span>
              </div>
            );
          }

          return <p key={idx}>{parseInlineFormatting(trimmed)}</p>;
        })}
      </div>
    );
  };

  const parseInlineFormatting = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-semibold text-slate-900">
            {part.slice(2, -2)}
          </strong>
        );
      }
      return part;
    });
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8.5rem)] max-w-5xl mx-auto px-2 sm:px-4 py-3">
      {/* Chat Header Bar */}
      <div className="bg-white border border-slate-200 rounded-xl px-4 py-3 mb-3 shadow-xs flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <OsteoCareLogo variant="badge-only" size="sm" className="shadow-xs" />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-slate-900 text-sm sm:text-base flex items-center">
                <span className="text-[#0A2540]">Osteo</span>
                <span className="text-[#10B981]">Care</span>
                <span className="text-[#0A2540]">-AI</span>
                <span className="text-slate-700 ml-1 font-semibold">Assistant</span>
              </h1>
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                · Voice Enabled (Tamil & English)
              </span>
            </div>
            <p className="text-xs text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#00B4D8]" />
              <span>
                {lang === 'en'
                  ? 'Bone Health • Early Awareness • Better Care'
                  : 'எலும்பு தொற்று விழிப்புணர்வு வழிகாட்டி'}
              </span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {currentlySpeakingId && (
            <button
              onClick={handleStopSpeaking}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 transition-colors cursor-pointer"
              title="Stop speaking"
            >
              <Square className="w-3 h-3 fill-rose-700" />
              <span>Stop Voice</span>
            </button>
          )}

          {messages.length > 0 && (
            <button
              onClick={onClearChat}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 rounded-md hover:bg-slate-50 transition-colors cursor-pointer"
              title={lang === 'en' ? 'Clear conversation' : 'உரையாடலை அழிக்க'}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{lang === 'en' ? 'Reset' : 'அழிக்க'}</span>
            </button>
          )}
        </div>
      </div>

      {/* API Error Notification */}
      {apiError && (
        <div className="mb-3 p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start justify-between gap-3 text-rose-950 text-xs sm:text-sm shadow-xs">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="space-y-1.5">
              <p className="font-semibold text-rose-900">
                {lang === 'en' ? 'Connection Notice' : 'இணைப்பு அறிவிப்பு'}
              </p>
              <p className="text-slate-700 leading-relaxed">{apiError}</p>
              <div className="pt-1 flex flex-wrap items-center gap-2">
                {onRetry && (
                  <button
                    onClick={onRetry}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{lang === 'en' ? 'Retry Message' : 'மீண்டும் முயற்சி செய்'}</span>
                  </button>
                )}
                <a
                  href="tel:108"
                  className="px-2.5 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 rounded-lg text-xs font-semibold transition-colors"
                >
                  {lang === 'en' ? 'Call 108 (Emergency)' : '108 அவசர உதவி'}
                </a>
              </div>
            </div>
          </div>
          <button
            onClick={onDismissError}
            className="text-rose-600 hover:text-rose-800 text-sm font-bold cursor-pointer p-1"
            title={lang === 'en' ? 'Dismiss' : 'நீக்கு'}
          >
            ✕
          </button>
        </div>
      )}

      {/* Voice Recognition Notice */}
      {micNotice && (
        <div className="mb-3 p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start justify-between gap-3 text-amber-900 text-xs">
          <div className="flex items-start gap-2">
            <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <p>{micNotice}</p>
          </div>
          <button
            onClick={() => setMicNotice(null)}
            className="text-amber-700 hover:text-amber-900 font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto custom-scrollbar bg-slate-50/60 rounded-xl border border-slate-200/80 p-3 sm:p-5 space-y-4">
        {messages.length === 0 ? (
          /* Clean & Professional Initial Stage */
          <div className="h-full flex flex-col justify-end max-w-2xl mx-auto w-full py-4 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider px-1">
              <Sparkles className="w-3.5 h-3.5 text-teal-600" />
              <span>
                {lang === 'ta' ? 'பரிந்துரைக்கப்படும் கேள்விகள்' : 'Suggested Questions'}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {QUICK_QUESTIONS.slice(0, 4).map((q) => (
                <button
                  key={q.id}
                  onClick={() => onSendMessage(lang === 'ta' ? q.textTa : q.textEn)}
                  className="p-3 bg-white border border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 rounded-xl text-left text-xs sm:text-sm font-medium text-slate-800 hover:text-teal-900 transition-all shadow-2xs cursor-pointer flex items-center justify-between gap-2 group"
                >
                  <span>{lang === 'ta' ? q.textTa : q.textEn}</span>
                  <Sparkles className="w-3.5 h-3.5 text-teal-500 opacity-40 group-hover:opacity-100 transition-opacity shrink-0" />
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === 'user';
            const isSpeakingThis = currentlySpeakingId === msg.id;

            return (
              <div
                key={msg.id}
                className={`flex gap-2.5 sm:gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="shrink-0 mt-0.5">
                    <OsteoCareLogo variant="badge-only" size="sm" className="drop-shadow-xs" />
                  </div>
                )}

                <div
                  className={`max-w-[88%] sm:max-w-[80%] rounded-2xl px-4 py-3 shadow-2xs ${
                    isUser
                      ? 'bg-teal-700 text-white rounded-br-xs'
                      : 'bg-white text-slate-800 border border-slate-200/90 rounded-bl-xs'
                  }`}
                >
                  {isUser ? (
                    <p className="text-sm sm:text-base leading-relaxed whitespace-pre-wrap">
                      {msg.content}
                    </p>
                  ) : (
                    renderFormattedContent(msg.content)
                  )}

                  {/* Message Bottom Action Bar */}
                  <div
                    className={`mt-2.5 pt-2 border-t flex items-center justify-between gap-3 text-xs ${
                      isUser
                        ? 'border-teal-600/60 text-teal-100'
                        : 'border-slate-100 text-slate-400'
                    }`}
                  >
                    <span className="tabular-nums font-mono text-[11px]">
                      {msg.timestamp}
                    </span>

                    {!isUser && (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleSpeak(msg.id, msg.content)}
                          className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                            isSpeakingThis
                              ? 'bg-rose-100 text-rose-700'
                              : 'hover:bg-teal-50 text-teal-700 hover:text-teal-900 border border-teal-200/60'
                          }`}
                          title={isSpeakingThis ? 'Stop speaking' : 'Read message aloud (ஸ்பீக்கர் ஒலி)'}
                        >
                          {isSpeakingThis ? (
                            <>
                              <Square className="w-3 h-3 fill-rose-700" />
                              <span>Stop</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3.5 h-3.5 text-teal-600" />
                              <span>{lang === 'en' ? 'Speak Aloud' : 'ஒலி வடிவில் கேட்க'}</span>
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => handleCopy(msg.id, msg.content)}
                          className="flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
                          title="Copy text"
                        >
                          {copiedId === msg.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span className="text-emerald-700">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span className="hidden sm:inline">Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}

                    {isUser && (
                      <div className="flex items-center gap-1 text-[11px] text-teal-200">
                        <User className="w-3 h-3" />
                        <span>You</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}

        {/* AI Loading indicator */}
        {isLoading && (
          <div className="flex gap-2.5 sm:gap-3 justify-start items-center py-1">
            <div className="shrink-0">
              <OsteoCareLogo variant="badge-only" size="xs" />
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl rounded-bl-xs px-3.5 py-2 shadow-2xs flex items-center gap-2">
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-600 animate-bounce [animation-delay:0s]" />
                <span className="w-1.5 h-1.5 rounded-full bg-teal-600 animate-bounce [animation-delay:0.2s]" />
                <span className="w-1.5 h-1.5 rounded-full bg-teal-600 animate-bounce [animation-delay:0.4s]" />
              </div>
              <span className="text-xs text-slate-500 font-medium">
                {lang === 'ta' ? 'சிந்திக்கிறது...' : 'Thinking...'}
              </span>
            </div>
          </div>
        )}

        {/* Fallback audio transcribing indicator */}
        {isTranscribingFallback && (
          <div className="p-3 bg-teal-50 border border-teal-200 rounded-xl flex items-center gap-2.5 text-teal-900 text-xs sm:text-sm animate-pulse">
            <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
            <span>
              {lang === 'en'
                ? 'Converting recorded speech to text with Gemini...'
                : 'பேசிய ஆடியோவை உரையாக மாற்றுகிறது...'}
            </span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* ChatGPT-Style Voice & Text Input Box */}
      <div className="mt-3 bg-white border border-slate-200 rounded-2xl p-2.5 shadow-sm">
        {/* Top toolbar: Language detection badge and language toggles */}
        <div className="flex items-center justify-between pb-2 px-1 text-xs text-slate-500 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-slate-600 font-medium">
              <Languages className="w-3.5 h-3.5 text-teal-600" />
              <span>Spoken Language:</span>
            </div>

            <button
              onClick={() => setMicLanguage('ta-IN')}
              className={`px-2 py-0.5 rounded text-xs font-semibold cursor-pointer transition-colors ${
                micLanguage === 'ta-IN'
                  ? 'bg-teal-100 text-teal-800 border border-teal-300'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              தமிழ் (Tamil)
            </button>

            <button
              onClick={() => setMicLanguage('en-IN')}
              className={`px-2 py-0.5 rounded text-xs font-semibold cursor-pointer transition-colors ${
                micLanguage === 'en-IN'
                  ? 'bg-teal-100 text-teal-800 border border-teal-300'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              English
            </button>

            {detectedVoiceLang && (
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-full border border-teal-200">
                <CheckCircle2 className="w-3 h-3 text-teal-600" />
                {detectedVoiceLang === 'ta' ? 'தமிழ் கண்டறியப்பட்டது' : 'English detected'}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Recording ON/OFF status badge */}
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium transition-colors ${
                isRecording
                  ? 'bg-rose-100 text-rose-700 font-semibold animate-pulse'
                  : 'bg-slate-100 text-slate-500'
              }`}
            >
              <Radio className={`w-3 h-3 ${isRecording ? 'text-rose-600 animate-spin' : 'text-slate-400'}`} />
              <span>{isRecording ? 'MIC ON (Recording)' : 'MIC Ready'}</span>
            </span>
          </div>
        </div>

        {/* Input Bar or ChatGPT-style Live Voice Bar */}
        <div className="relative pt-2">
          {isRecording ? (
            /* ChatGPT-style Voice Recording Interface */
            <div className="min-h-[52px] bg-slate-900 text-white rounded-xl px-4 py-2.5 flex items-center justify-between gap-3 shadow-md animate-in fade-in duration-200">
              {/* Left: Recording timer & red dot */}
              <div className="flex items-center gap-2.5 shrink-0">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
                </span>
                <span className="font-mono text-xs font-bold text-rose-300 tabular-nums">
                  {formatSeconds(recordingDuration)}
                </span>
              </div>

              {/* Center: Live Soundwave visualizer bars + interim speech preview */}
              <div className="flex-1 flex flex-col items-center justify-center px-2 min-w-0">
                {/* Audio Waveform animation */}
                <div className="flex items-center gap-1 h-5 mb-1">
                  <span className="w-1 h-2 bg-teal-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                  <span className="w-1 h-4 bg-teal-300 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                  <span className="w-1 h-5 bg-emerald-400 rounded-full animate-bounce"></span>
                  <span className="w-1 h-3 bg-teal-300 rounded-full animate-bounce [animation-delay:-0.2s]"></span>
                  <span className="w-1 h-4 bg-teal-400 rounded-full animate-bounce [animation-delay:-0.35s]"></span>
                  <span className="w-1 h-2 bg-emerald-300 rounded-full animate-bounce [animation-delay:-0.1s]"></span>
                </div>

                <p className="text-xs text-slate-300 line-clamp-1 italic text-center w-full">
                  {liveTranscript ||
                    (micLanguage === 'ta-IN'
                      ? 'பேசவும்... (அழுத்திப் பிடிக்கவும் அல்லது முடித்ததும் விடவும்)'
                      : 'Listening... (Speak clearly into your microphone)')}
                </p>
              </div>

              {/* Right: Cancel button & Done button */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleCancelRecording}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-rose-900/60 text-slate-300 hover:text-rose-300 transition-colors cursor-pointer"
                  title="Cancel and discard recording"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <button
                  onClick={handleFinishRecording}
                  className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold flex items-center gap-1 transition-colors shadow-xs cursor-pointer"
                  title="Release or tap to transcribe speech to text"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Done</span>
                </button>
              </div>
            </div>
          ) : (
            /* Normal Textarea + Integrated ChatGPT-style Microphone button */
            <div className="flex items-end gap-2">
              {/* Text input area */}
              <textarea
                ref={textareaRef}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={
                  lang === 'en'
                    ? "Ask about osteomyelitis, wounds, or bone pain (Hold mic or type)..."
                    : "எலும்பு வலி, புண், முதலுதவி பற்றி கேளுங்கள் (மைக்கை அழுத்திப் பேசவும்)..."
                }
                rows={1}
                className="flex-1 max-h-32 min-h-[44px] py-2.5 px-3.5 text-sm sm:text-base border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-teal-500 focus:border-teal-500 resize-none text-slate-900 placeholder:text-slate-400 bg-white"
              />

              {/* Modern ChatGPT-Style Microphone Button (Press & Hold) */}
              <button
                onMouseDown={handleMicMouseDown}
                onMouseUp={handleMicMouseUp}
                onTouchStart={handleMicTouchStart}
                onTouchEnd={handleMicTouchEnd}
                className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-teal-50 text-slate-700 hover:text-teal-700 hover:border-teal-300 active:scale-95 transition-all cursor-pointer relative shrink-0 shadow-2xs group flex items-center justify-center"
                title={
                  lang === 'en'
                    ? 'Press and hold to record voice (English & Tamil)'
                    : 'குரல் பதிவு செய்ய அழுத்திப் பிடிக்கவும் (தமிழ் & English)'
                }
                aria-label="Microphone Voice Input"
              >
                <Mic className="w-5 h-5 text-teal-700 group-hover:scale-110 transition-transform" />
              </button>

              {/* Send Button */}
              <button
                onClick={handleSend}
                disabled={!inputText.trim() || isLoading}
                className="p-2.5 rounded-xl bg-teal-600 text-white hover:bg-teal-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors shrink-0 shadow-xs cursor-pointer flex items-center justify-center"
                title="Send Message"
                aria-label="Send Message"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>

        {/* Input Footer Instructions */}
        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500 px-1">
          <span className="flex items-center gap-1.5 text-slate-500">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-teal-600"></span>
            <span>{lang === 'ta' ? 'Enter அழுத்தி அனுப்பலாம்' : 'Press Enter to send'}</span>
          </span>

          <span className="hidden sm:inline text-slate-400">
            Shift + Enter for new line
          </span>
        </div>
      </div>
    </div>
  );
};
