import React from 'react';

export interface OsteoCareLogoProps {
  variant?: 'horizontal' | 'badge-only' | 'full' | 'stacked';
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  className?: string;
}

export const OsteoCareLogo: React.FC<OsteoCareLogoProps> = ({
  variant = 'horizontal',
  size = 'md',
  showTagline = false,
  className = '',
}) => {
  // Size metrics mapping
  const sizeMap = {
    xs: {
      badge: 'w-6 h-6',
      iconSize: 14,
      title: 'text-xs',
      tagline: 'text-[9px]',
      gap: 'gap-1.5',
    },
    sm: {
      badge: 'w-8 h-8',
      iconSize: 18,
      title: 'text-sm font-bold',
      tagline: 'text-[10px]',
      gap: 'gap-2',
    },
    md: {
      badge: 'w-10 h-10',
      iconSize: 22,
      title: 'text-base font-bold',
      tagline: 'text-xs',
      gap: 'gap-2.5',
    },
    lg: {
      badge: 'w-14 h-14',
      iconSize: 32,
      title: 'text-xl font-extrabold',
      tagline: 'text-xs',
      gap: 'gap-3',
    },
    xl: {
      badge: 'w-20 h-20',
      iconSize: 44,
      title: 'text-2xl font-extrabold',
      tagline: 'text-xs font-semibold tracking-wider',
      gap: 'gap-3.5',
    },
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  // The Navy Badge Icon with Stylized Bone & Protective Cyan/Green Health Ribbon
  const IconBadge = (
    <div
      className={`${currentSize.badge} rounded-xl sm:rounded-2xl bg-[#0A2540] flex items-center justify-center shadow-sm shrink-0 border border-slate-700/20 relative overflow-hidden group`}
      style={{
        background: 'linear-gradient(135deg, #0A2540 0%, #0F3860 100%)',
      }}
    >
      {/* Subtle background glow */}
      <div className="absolute inset-0 bg-radial from-teal-400/10 via-transparent to-transparent pointer-events-none" />

      <svg
        width={currentSize.iconSize}
        height={currentSize.iconSize}
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="relative z-10 transition-transform group-hover:scale-105 duration-200"
      >
        {/* Glowing health ribbon arc */}
        <path
          d="M8 28C8 17.5066 16.5066 9 27 9C34.5 9 40 13.5 42 19"
          stroke="#00B4D8"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeDasharray="1 1"
          opacity="0.6"
        />

        {/* Dynamic protective health curve */}
        <path
          d="M6 34C10 39 18 42 26 40C35.5 37.5 42 29 42 18"
          stroke="#10B981"
          strokeWidth="3.5"
          strokeLinecap="round"
        />

        {/* Central Stylized Medical Bone Element */}
        <g transform="translate(14, 12)">
          {/* Top Knobs */}
          <circle cx="5" cy="5" r="4.5" fill="#FFFFFF" />
          <circle cx="15" cy="5" r="4.5" fill="#FFFFFF" />
          {/* Central Bone Shaft */}
          <rect x="7" y="4" width="6" height="16" rx="2" fill="#FFFFFF" />
          {/* Bottom Knobs */}
          <circle cx="5" cy="19" r="4.5" fill="#FFFFFF" />
          <circle cx="15" cy="19" r="4.5" fill="#FFFFFF" />

          {/* Medical Cross Accent on Bone Core */}
          <path
            d="M10 9V15M7 12H13"
            stroke="#10B981"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </g>

        {/* Small vitality sparkle */}
        <circle cx="36" cy="13" r="2.5" fill="#00B4D8" />
        <circle cx="12" cy="37" r="2" fill="#10B981" />
      </svg>
    </div>
  );

  // Wordmark element
  const Wordmark = (
    <div className="flex flex-col">
      <div className={`tracking-tight leading-none ${currentSize.title}`}>
        <span className="text-[#0A2540]">Osteo</span>
        <span className="text-[#10B981]">Care</span>
        <span className="text-[#00B4D8] font-bold">-AI</span>
      </div>
      {showTagline && (
        <span
          className={`text-slate-500 font-medium mt-1 leading-normal ${currentSize.tagline}`}
        >
          Bone Health • Early Awareness • Better Care
        </span>
      )}
    </div>
  );

  if (variant === 'badge-only') {
    return <div className={`inline-flex ${className}`}>{IconBadge}</div>;
  }

  if (variant === 'full' || variant === 'stacked') {
    return (
      <div
        className={`flex flex-col items-center text-center ${currentSize.gap} ${className}`}
      >
        {IconBadge}
        <div className="flex flex-col items-center">
          <div className={`tracking-tight leading-none ${currentSize.title}`}>
            <span className="text-[#0A2540]">Osteo</span>
            <span className="text-[#10B981]">Care</span>
            <span className="text-[#00B4D8] font-bold">-AI</span>
          </div>
          {showTagline && (
            <span
              className={`text-slate-500 font-medium mt-1.5 leading-normal ${currentSize.tagline}`}
            >
              Bone Health • Early Awareness • Better Care
            </span>
          )}
        </div>
      </div>
    );
  }

  // Default 'horizontal' variant
  return (
    <div className={`flex items-center ${currentSize.gap} ${className}`}>
      {IconBadge}
      {Wordmark}
    </div>
  );
};
