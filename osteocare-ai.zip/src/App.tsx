import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { ChatView } from './components/ChatView';
import { EducationView } from './components/EducationView';
import { WorkerView } from './components/WorkerView';
import { HelplineView } from './components/HelplineView';
import { ChatMessage, Language } from './types';
import { sendMessageToGemini } from './services/api';
import { OsteoCareLogo } from './components/OsteoCareLogo';
import { HeartPulse, PhoneCall, X } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'chat' | 'guide' | 'safety' | 'helplines'>('chat');
  const [lang, setLang] = useState<Language>('en');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [lastFailedText, setLastFailedText] = useState<string | null>(null);

  // Load language preference from localStorage if set
  useEffect(() => {
    try {
      const savedLang = localStorage.getItem('osteocare_lang') as Language;
      if (savedLang === 'en' || savedLang === 'ta') {
        setLang(savedLang);
      }
    } catch {
      // ignore
    }
  }, []);

  const handleSetLang = (newLang: Language) => {
    setLang(newLang);
    try {
      localStorage.setItem('osteocare_lang', newLang);
    } catch {
      // ignore
    }
  };

  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    // Auto-detect language seamlessly from user input so user never has to switch manually
    const containsTamilText = /[\u0B80-\u0BFF]/.test(text);
    if (containsTamilText && lang !== 'ta') {
      setLang('ta');
    } else if (!containsTamilText && /[a-zA-Z]/.test(text) && lang !== 'en') {
      setLang('en');
    }

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setIsLoading(true);
    setApiError(null);
    setLastFailedText(text.trim());

    try {
      const reply = await sendMessageToGemini(text, messages);

      const aiMsg: ChatMessage = {
        id: `model-${Date.now()}`,
        role: 'model',
        content: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
      setLastFailedText(null);
    } catch (err: any) {
      console.error('Chat error:', err);
      setApiError(
        err?.message ||
          (lang === 'en'
            ? 'Unable to communicate with OsteoCare-AI. Please check your network or try again.'
            : 'AI மருத்துவ உதவியாளருடன் இணைக்க முடியவில்லை. மீண்டும் முயற்சிக்கவும்.')
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetry = () => {
    if (!lastFailedText || isLoading) return;
    // Remove the trailing unfulfilled user message before re-sending
    setMessages((prev) => (prev.length > 0 && prev[prev.length - 1].role === 'user' ? prev.slice(0, -1) : prev));
    handleSendMessage(lastFailedText);
  };

  const handleClearChat = () => {
    setMessages([]);
    setApiError(null);
    setLastFailedText(null);
  };

  const handleAskQuestionFromGuide = (query: string) => {
    setActiveTab('chat');
    handleSendMessage(query);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-800">
      {/* Top Bar Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        lang={lang}
        setLang={handleSetLang}
        onEmergencyClick={() => setShowEmergencyModal(true)}
      />

      {/* Global Medical Disclaimer Header */}
      <DisclaimerBanner lang={lang} />

      {/* Main Content Stage */}
      <main className="flex-1 flex flex-col">
        {activeTab === 'chat' && (
          <ChatView
            messages={messages}
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            lang={lang}
            onSetLang={handleSetLang}
            onClearChat={handleClearChat}
            apiError={apiError}
            onDismissError={() => setApiError(null)}
            onRetry={lastFailedText ? handleRetry : undefined}
          />
        )}

        {activeTab === 'guide' && (
          <EducationView lang={lang} onAskQuestion={handleAskQuestionFromGuide} />
        )}

        {activeTab === 'safety' && (
          <WorkerView lang={lang} onAskQuestion={handleAskQuestionFromGuide} />
        )}

        {activeTab === 'helplines' && <HelplineView lang={lang} />}
      </main>

      {/* Clean Editorial Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 px-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <OsteoCareLogo variant="horizontal" size="xs" showTagline={false} />
            <span className="text-slate-400 hidden sm:inline">|</span>
            <span className="text-slate-600 font-medium">Public Bone Health Awareness Platform</span>
          </div>

          <div className="flex items-center gap-6">
            <span>Non-diagnostic Educational Tool</span>
            <span>·</span>
            <button
              onClick={() => setActiveTab('helplines')}
              className="text-teal-700 hover:underline cursor-pointer"
            >
              Emergency Helpline 108
            </button>
          </div>
        </div>
      </footer>

      {/* Emergency Modal */}
      {showEmergencyModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5 text-rose-700">
                <div className="w-9 h-9 rounded-lg bg-rose-100 flex items-center justify-center">
                  <PhoneCall className="w-5 h-5 text-rose-700" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">
                  {lang === 'en' ? 'Emergency Medical Services' : 'அவசர மருத்துவ உதவி'}
                </h3>
              </div>
              <button
                onClick={() => setShowEmergencyModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {lang === 'en'
                ? 'If you or someone nearby is experiencing unbearable throbbing bone pain with high fever, foul pus leakage, an open bone fracture, or sudden inability to walk, seek immediate hospital attention.'
                : 'தாங்க முடியாத எலும்பு குடைச்சல் வலி, அதிக காய்ச்சல், துர்நாற்றத்துடன் சீழ் வடிதல், அல்லது நடக்க முடியாத நிலை ஏற்பட்டால் உடனடியாக ஆம்புலன்ஸ் அல்லது மருத்துவமனைக்குச் செல்லவும்.'}
            </p>

            <div className="space-y-2.5 pt-2">
              <a
                href="tel:108"
                className="w-full py-3 px-4 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-colors shadow-xs"
              >
                <PhoneCall className="w-4 h-4" />
                <span>{lang === 'en' ? 'Dial 108 (Free Emergency Ambulance)' : '108 டயல் செய் (இலவச ஆம்புலன்ஸ்)'}</span>
              </a>

              <a
                href="tel:104"
                className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-colors shadow-xs"
              >
                <HeartPulse className="w-4 h-4" />
                <span>{lang === 'en' ? 'Dial 104 (Free Medical Advice in Tamil)' : '104 டயல் செய் (இலவச மருத்துவ ஆலோசனை)'}</span>
              </a>
            </div>

            <button
              onClick={() => setShowEmergencyModal(false)}
              className="w-full py-2 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
            >
              {lang === 'en' ? 'Close Window' : 'மூடு'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
