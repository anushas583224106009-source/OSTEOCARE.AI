export type Language = 'en' | 'ta';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  language?: 'en' | 'ta';
  isAudioPlaying?: boolean;
}

export interface QuickQuestion {
  id: string;
  textEn: string;
  textTa: string;
  category: 'general' | 'symptoms' | 'prevention' | 'emergency';
}

export interface HelplineContact {
  number: string;
  titleEn: string;
  titleTa: string;
  descriptionEn: string;
  descriptionTa: string;
  badge: string;
  isEmergency?: boolean;
}

export interface EducationalSection {
  id: string;
  titleEn: string;
  titleTa: string;
  subtitleEn: string;
  subtitleTa: string;
  contentEn: string[];
  contentTa: string[];
  image?: string;
  warningEn?: string;
  warningTa?: string;
}
