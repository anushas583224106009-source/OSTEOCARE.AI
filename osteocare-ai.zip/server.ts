import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// CORS & Preflight headers
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }
  next();
});

// Helper to safely get the Gemini API Key from environment or AI Studio secrets
function getApiKey(): string | null {
  if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim()) {
    return process.env.GEMINI_API_KEY.trim();
  }
  if (process.env.GOOGLE_API_KEY && process.env.GOOGLE_API_KEY.trim()) {
    return process.env.GOOGLE_API_KEY.trim();
  }

  // Check /app/.dev.env.json where AI Studio persists workspace secrets
  try {
    const candidates = [
      '/app/.dev.env.json',
      path.resolve(__dirname, '.dev.env.json'),
      path.resolve(__dirname, '../.dev.env.json'),
    ];
    for (const p of candidates) {
      if (fs.existsSync(p)) {
        const content = fs.readFileSync(p, 'utf-8');
        const parsed = JSON.parse(content);
        if (parsed.GEMINI_API_KEY && typeof parsed.GEMINI_API_KEY === 'string') {
          return parsed.GEMINI_API_KEY.trim();
        }
        if (parsed.GOOGLE_API_KEY && typeof parsed.GOOGLE_API_KEY === 'string') {
          return parsed.GOOGLE_API_KEY.trim();
        }
      }
    }
  } catch (err) {
    // ignore
  }

  return null;
}

const SYSTEM_INSTRUCTION = `
You are OsteoCare-AI, a specialized health awareness assistant for osteomyelitis (bone infection / எலும்பு தொற்று).

Response Rules:
1. Conciseness & Structure:
   - Provide direct, concise, practical answers first. Keep responses clear and easy to read.
   - Use bullet points and short paragraphs. Avoid long introductory filler or unnecessary pleasantries.

2. Language Support (Automatic):
   - If the user writes or speaks in Tamil (or Tanglish): Reply in natural, friendly, clear conversational Tamil (பேச்சுத் தமிழ்). Use common loan words naturally (டாக்டர், ஆஸ்பத்திரி, எக்ஸ்-ரே, ஆன்டிபயாடிக், கட்டு).
   - If the user writes or speaks in English: Reply in natural, clear, simple English without dense medical jargon.
   - Match the user's language automatically without asking them to select.

3. Domain Focus (Osteomyelitis & Wound Safety):
   - Symptoms: Deep throbbing bone pain (worse at night), warmth/swelling, fever/chills, chronic pus/fluid drainage, inability to bear weight.
   - High-Risk Context: Farm/rural injuries (கருவேல முள், rusty nails, soil-contaminated cuts), diabetic foot ulcers spreading to bone.
   - First Aid: Wash deep cuts immediately with clean running water and soap for 3–5 minutes. Cover with a clean sterile dressing.
   - DANGER WARNING: Never apply cow dung, ash, lime, or unsterilized herbal pastes on wounds (pushes bacteria deep into bone).
   - Hospital Care: Doctors diagnose with X-rays, blood tests, or MRI, and treat with IV antibiotics or surgical debridement. Urge getting a Tetanus (TT) shot within 24–48 hours at a PHC.

4. Medical Safety & Disclaimer:
   - Non-diagnostic educational tool only. Never claim to diagnose or prescribe specific drugs/dosages.
   - Strongly recommend prompt orthopedic evaluation at a Primary Health Centre (PHC) or Government Hospital (GH).
   - For emergency signs (severe unbearable bone pain, high fever with shaking, heavy pus, or inability to walk), urge immediate hospital care or dialing 108.
`;

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  const apiKey = getApiKey();
  res.json({
    status: 'ok',
    appName: 'OsteoCare-AI',
    hasApiKey: Boolean(apiKey),
    timestamp: new Date().toISOString(),
  });
});

// Chat endpoint
app.post('/api/chat', async (req: Request, res: Response): Promise<void> => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string' || message.trim() === '') {
      res.status(400).json({
        success: false,
        error: 'Message cannot be empty.',
      });
      return;
    }

    const apiKey = getApiKey();
    if (!apiKey) {
      // Return 200 with clear message so NGINX does not intercept with warmup HTML
      res.status(200).json({
        success: false,
        error: 'Gemini API key is not configured in the server environment. Please configure GEMINI_API_KEY in the Secrets panel in AI Studio settings to enable live AI responses.',
      });
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    // Format contents including conversation history (keep last 4 messages to minimize latency and token load)
    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      const recentHistory = history.slice(-4);
      for (const item of recentHistory) {
        if (item && item.role && item.content) {
          contents.push({
            role: item.role === 'user' ? 'user' : 'model',
            parts: [{ text: item.content }],
          });
        }
      }
    }

    // Append current user message
    contents.push({
      role: 'user',
      parts: [{ text: message.trim() }],
    });

    const modelsToTry = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest'];
    let replyText = '';
    let lastError: any = null;

    for (const modelName of modelsToTry) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: contents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.3,
            maxOutputTokens: 650,
          },
        });
        if (response.text) {
          replyText = response.text;
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`Model ${modelName} encountered an issue:`, err?.message || err);
      }
    }

    if (!replyText && lastError) {
      throw lastError;
    }

    res.status(200).json({
      success: true,
      reply: replyText || 'I apologize, but I could not formulate a response at this moment. Please try asking again.',
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error generating AI response:', error);

    const isQuotaOrAuth =
      error?.status === 401 ||
      error?.status === 403 ||
      error?.status === 429 ||
      error?.message?.includes('API_KEY_INVALID') ||
      error?.message?.includes('quota');

    const errorMessage = isQuotaOrAuth
      ? 'The Gemini AI service encountered an authorization or quota issue. Please check your GEMINI_API_KEY in the Secrets panel.'
      : 'An unexpected error occurred while communicating with OsteoCare-AI. Please check your network and try again.';

    // Return status 200 with success: false to prevent NGINX error_page intercept
    res.status(200).json({
      success: false,
      error: errorMessage,
    });
  }
});

// Server-side Text-to-Speech endpoint using gemini-3.8-flash-lite-tts
app.post('/api/tts', async (req: Request, res: Response): Promise<void> => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  try {
    const { text, voice } = req.body;
    if (!text || typeof text !== 'string') {
      res.status(400).json({ success: false, error: 'Text is required for speech synthesis.' });
      return;
    }

    const apiKey = getApiKey();
    if (!apiKey) {
      res.status(200).json({ success: false, error: 'Gemini API key not configured for TTS.' });
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    // Truncate text to reasonable length for TTS audio clip (~400 characters)
    const cleanText = text.replace(/[*#_`]/g, '').slice(0, 400);

    const ttsResponse = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: cleanText,
              speechMetadata: {
                style: 'Gentle, clear healthcare educator',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice || 'Kore' },
          },
        },
      },
    });

    const base64Audio = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      res.status(200).json({ success: true, audioBase64: base64Audio, format: 'audio/wav' });
    } else {
      res.status(200).json({ success: false, error: 'Failed to synthesize speech audio.' });
    }
  } catch (err: any) {
    console.error('Server TTS error:', err);
    res.status(200).json({ success: false, error: 'Server speech synthesis not available.' });
  }
});

// Audio transcription endpoint using gemini-3.5-transcribe
app.post('/api/transcribe', async (req: Request, res: Response): Promise<void> => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  try {
    const { audioBase64, mimeType } = req.body;
    if (!audioBase64 || typeof audioBase64 !== 'string') {
      res.status(400).json({ success: false, error: 'Audio data is required for transcription.' });
      return;
    }

    const apiKey = getApiKey();
    if (!apiKey) {
      res.status(200).json({ success: false, error: 'Gemini API key is not configured.' });
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType || 'audio/webm',
              data: audioBase64,
            },
          },
          {
            text: 'Please transcribe the spoken audio accurately. If spoken in Tamil, transcribe in Tamil script. If spoken in English, transcribe in English. If Tanglish, transcribe as spoken. Output ONLY the plain transcription text, with no extra commentary or quotes.',
          },
        ],
      },
    });

    const transcript = response.text?.trim() || '';
    const isTamil = /[\u0B80-\u0BFF]/.test(transcript);

    res.status(200).json({
      success: true,
      transcript,
      detectedLanguage: isTamil ? 'ta' : 'en',
    });
  } catch (err: any) {
    console.error('Server Transcribe error:', err);
    res.status(200).json({ success: false, error: 'Audio transcription failed. Please try speaking again.' });
  }
});

// Vite or Static file serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`OsteoCare-AI server listening on http://0.0.0.0:${PORT} (${isProd ? 'Production' : 'Development'})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start OsteoCare-AI server:', err);
  process.exit(1);
});
